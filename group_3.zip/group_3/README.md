Héritage GO

*************************************
HOW TO USE:
    RIGHT-CLICK on index.html then select OPEN WITH <your favorite browser>
    Highly-recommended browser: Lastest version of Google Chrome

*************************************
Description
Héritage GO is a social networking service dedicated to cultural and historical heritages, developed by the non-profit organization Heritage Observatory.
*************************************
Learning outcomes
HTML: - Know how to use semantic markup
HTML: - Know how to structure the DOM properly
CSS: - Know when to use ids and classes
CSS: - Understand the grid system
CSS: - Implement responsive layouts with media queries
JS: - Manipulate the DOM
