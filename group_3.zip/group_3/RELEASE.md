VERSION 0.1.0 - 15/06/2019:
  - Waypoint 1 to 17 : Automatically generate new photo while scrolling.
