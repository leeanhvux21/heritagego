function get_photo(photos, offset_number){
  for (index = 0; index < photos.length; index++)
  mHeritageGoService.getPhoto(photos[index])
.then(function (photo) {display(photo, offset_number); })
};

function display(photo, offset_number){
  var clone = $('.post_1:last').clone(false).appendTo("section").hide().fadeIn(1600) ;
  clone.removeClass("post_1")
  clone.find('#photo').attr('src',"http:" + photo['image_url']);
  clone.find('#area_name').text(" " + photo["area_name"]);
  clone.find('#photo_name').text(" " + photo["title"][0]["content"]);
  clone.find('#user_avatar').attr('src',"http:" + photo["account"]["picture_url"]);
  clone.find('#creation_time').text(" " + photo["creation_time"].substring(0,4));
  clone.find("#demo").attr('src', "./img/trans_icon.png");
  clone.attr('id', ""+offset_number)
  
  var x = $("#"+offset_number+' [id^="lang_"]');
  for (index = 0; index < x.length; index++) {
    var y = $("#"+offset_number+' [id^="lang_'+index+'"]');
    y.attr("id", "lang_"+index+"_"+offset_number)
  }
};

function get_photos(offset_number){
  mHeritageGoService.getPhotos({offset:offset_number, limit:1})
  .then(photos => { get_photo(photos, offset_number); })
};

var offset_number = 3;

$(window).scroll(function() {
  if($(window).scrollTop() >= $(document).height() - $(window).height()) {
    get_photos(offset_number, 1);
    offset_number++;
  }
  
  document.getElementById("clone-feed").innerHTML = document.getElementById("new_feed").innerHTML;
  document.getElementById("clone-feed-container").scrollTop = window.scrollY;  
});


$(document).ready(get_three_photos());

function get_three_photos(){
  for (i = 0; i < 3; i++) { 
    get_photos(i);

  }
};

function suggest_caption(photoId, caption, locale){
  mHeritageGoService
  .suggestPhotoCaption(photoId, caption, locale)
  .catch(error => {console.log(error);});
 };



var last_new_feed="-1";
var last_post_id;
function change_lang(flag){
  var flag_id = flag.id.split("_");
  ["#clone-feed-container", "#new_feed"].forEach(element => {
    var post_id = $(element).find("#"+flag_id[flag_id.length-1]);
    last_post_id = post_id;
    post_id.find("#demo").attr("src", flag.src);
    post_id.find("#photo_name").attr("contenteditable", "true");
    
    if (last_new_feed != flag_id[flag_id.length-1]){
      post_id = $(element).find("#"+last_new_feed);
      post_id.find("#demo").attr("src", "./img/trans_icon.png");
      post_id.find("#photo_name").attr("contenteditable", "false");
    }
  });
  last_new_feed = flag_id[flag_id.length-1];
}

var elementIsClicked = false;
function myfun(e) {
  
  if (last_new_feed != e.id){
    ["#clone-feed-container", "#new_feed"].forEach(element => {
      var post_id = $(element).find("#"+last_new_feed);
      post_id.find("#demo").attr("src", "./img/trans_icon.png");
      post_id.find("#photo_name").attr("contenteditable", "false");
    });
  }
}

$(document).keypress(function(event){
	var keycode = (event.keyCode ? event.keyCode : event.which);
	if(keycode == '13'){
		last_post_id.find("#photo_name").attr("contenteditable", "false");
    last_post_id.find("#demo").attr("src", "./img/trans_icon.png");
    // suggest_caption(photo_id, caption, locale)
    // photo_id: div lastpost 's id
    // caption: #photo_name's value
    // locale: alpha3-code
	}
})

