var last_new_feed="-1";
var last_post_id;
var offset_number = 3;
var elementIsClicked = false;
var default_locale = find_default_locale();
var already_suggested= false;
var stopped = false;

function find_default_locale(){
  language_convert = {
    "aa":"aar", "ab":"abk", "af":"afr", "ak":"aka", "am":"amh", "ar":"ara", "an":"arg", "as":"asm", "av":"ava", "ae":"ave",
    "ay":"aym", "az":"aze", "ba":"bak", "bm":"bam", "be":"bel", "bn":"ben", "bh":"bih", "bi":"bis", "bo":"bod", "bs":"bos",
    "br":"bre", "bg":"bul", "ca":"cat", "cs":"ces", "ch":"cha", "ce":"che", "cu":"chu", "cv":"chv", "kw":"cor", "co":"cos",
    "cr":"cre", "cy":"cym", "da":"dan", "de":"deu", "dv":"div", "dz":"dzo", "el":"ell", "en":"eng", "eo":"epo", "et":"est",
    "eu":"eus", "ee":"ewe", "fo":"fao", "fa":"fas", "fj":"fij", "fl":"fil", "fi":"fin", "fr":"fra", "fy":"fry", "ff":"ful",
    "gd":"gla", "ga":"gle", "gl":"glg", "gv":"glv", "gn":"grn", "gu":"guj", "ht":"hat", "ha":"hau", "sh":"hbs", "he":"heb",
    "hz":"her", "hi":"hin", "ho":"hmo", "hr":"hrv", "hu":"hun", "hy":"hye", "ig":"ibo", "io":"ido", "ii":"iii", "iu":"iku",
    "ie":"ile", "ia":"ina", "id":"ind", "ik":"ipk", "is":"isl", "it":"ita", "jv":"jav", "ja":"jpn", "kl":"kal", "kn":"kan",
    "ks":"kas", "ka":"kat", "kr":"kau", "kk":"kaz", "km":"khm", "ki":"kik", "rw":"kin", "ky":"kir", "kv":"kom", "kg":"kon",
    "ko":"kor", "kj":"kua", "ku":"kur", "lo":"lao", "la":"lat", "lv":"lav", "li":"lim", "ln":"lin", "lt":"lit", "lb":"ltz",
    "lu":"lub", "lg":"lug", "mh":"mah", "ml":"mal", "mr":"mar", "mk":"mkd", "mg":"mlg", "mt":"mlt", "mn":"mon", "mi":"mri",
    "ms":"msa", "my":"mya", "na":"nau", "nv":"nav", "nr":"nbl", "nd":"nde", "ng":"ndo", "ne":"nep", "nl":"nld", "nn":"nno",
    "nb":"nob", "no":"nor", "ny":"nya", "oc":"oci", "oj":"oji", "or":"ori", "om":"orm", "os":"oss", "pa":"pan", "pi":"pli",
    "pl":"pol", "pt":"por", "ps":"pus", "qu":"que", "rm":"roh", "ro":"ron", "rn":"run", "ru":"rus", "sg":"sag", "sa":"san",
    "si":"sin", "sk":"slk", "sl":"slv", "se":"sme", "sm":"smo", "sn":"sna", "sd":"snd", "so":"som", "st":"sot", "es":"spa",
    "sq":"sqi", "sc":"srd", "sr":"srp", "ss":"ssw", "su":"sun", "sw":"swa", "sv":"swe", "ty":"tah", "ta":"tam", "tt":"tat",
    "te":"tel", "tg":"tgk", "tl":"tgl", "th":"tha", "ti":"tir", "to":"ton", "tn":"tsn", "ts":"tso", "tk":"tuk", "tr":"tur",
    "tw":"twi", "ug":"uig", "uk":"ukr", "ur":"urd", "uz":"uzb", "ve":"ven", "vi":"vie", "vo":"vol", "wa":"wln", "wo":"wol",
    "xh":"xho", "yi":"yid", "yo":"yor", "za":"zha", "zh":"zho", "zu":"zul"
  };
  return language_convert[navigator.language.substring(0,2)];
};


function find_suitable_language(photo){
  var english_available = false;
  var available_languages = photo["title"];
  for (index = 0; index < photo["title"].length; index++){
    let element = photo["title"][index];
    if (element["locale"] == default_locale) {
      return element["content"];
    }else if (element["locale"] == "en") {
      english_available = true;
      var english_caption = element["content"];
    };
};
  if (english_available == true){
    return english_caption;
  };
  return photo["title"][0]["content"];
};


function get_photo(photos){
  for (index = 0; index < photos.length; index++){
  mHeritageGoService.getPhoto(photos[index]).then( function (photo) {display(photo);})
}
};


function display(photo){
  var suitable_language = find_suitable_language(photo);
  var clone = $('.post_1:last').clone(false).appendTo("section").hide().fadeIn(1600) ;
  clone.removeClass("post_1")
  clone.find('#photo').attr('src',"http:" + photo['image_url']);
  clone.find('#area_name').text(photo["area_name"]);
  clone.find('#photo_name').text(suitable_language);
  clone.find('#user_avatar').attr('src',"http:" + photo["account"]["picture_url"]);
  clone.find('#creation_time').text(photo["capture_time"]);
  clone.find("#demo").attr('src', "./img/trans_icon.png");
  clone.find("#demo").attr("alt", suitable_language);
  var photo_id = photo["photo_id"]
  clone.attr('id', ""+photo_id);

  var x = $("#"+photo_id+' [id^="lang_"]');
  for (index = 0; index < x.length; index++) {
    var y = $("#"+photo_id+' [id^="lang_'+index+'"]');
    y.attr("id", "lang_"+index+"_"+photo_id)
  }
};


function get_photos(offset_number){
  mHeritageGoService.getPhotos({offset:offset_number, limit:1})
  .then(photos => {get_photo(photos, offset_number); })
};


$(window).scroll(function() {
  if($(window).scrollTop()+2 >= $(document).height() - $(window).height()) {
    get_photos(offset_number, 1);
    offset_number++;
  }
  $(".popup_content").css("display", "none");
  document.getElementById("clone-feed").innerHTML = document.getElementById("new_feed").innerHTML;
  document.getElementById("clone-feed-container").scrollTop = window.scrollY;

  ["#clone-feed-container", "#new_feed"].forEach(element => {
    var post_id = $(element).find("#"+last_new_feed);
    post_id.find("#demo").attr("src", "./img/trans_icon.png");
    post_id.find("#photo_name").attr("contenteditable", "false");
  });
});


$(document).ready(get_three_photos());

function get_three_photos(){
  for (i = 0; i < 3; i++) {
    get_photos(i);
  }
};


function change_lang(flag){
  var flag_id = flag.id.split("_");
  ["#clone-feed-container", "#new_feed"].forEach(element => {
    var post_id = $(element).find("#"+flag_id[flag_id.length-1]);
    last_post_id = post_id;
    post_id.find("#demo").attr("src", flag.src);
    post_id.find("#photo_name").attr("contenteditable", "true");

    if (last_new_feed != flag_id[flag_id.length-1]){
      post_id = $(element).find("#"+last_new_feed);
      post_id.find("#demo").attr("src", "./img/trans_icon.png");
      post_id.find("#photo_name").attr("contenteditable", "false");
    }
  });
  last_new_feed = flag_id[flag_id.length-1];
}


function myfun(e) {
  if (last_new_feed != e.id){
    ["#clone-feed-container", "#new_feed"].forEach(element => {
      var post_id = $(element).find("#"+last_new_feed);
      post_id.find("#demo").attr("src", "./img/trans_icon.png");
      post_id.find("#photo_name").attr("contenteditable", "false");
    });
  }
}


$(document).keypress(function(event){
  var keycode = (event.keyCode ? event.keyCode : event.which);
	if(keycode === 13){
    last_post_id.find("#photo_name").removeAttr("onfocusout");
    suggest_caption();
    last_post_id.find("#photo_name").attr("onfocusout", "suggest_caption()");
	}
});


function suggest_caption(){
  try {
    last_post_id.find("#photo_name").attr("contenteditable", "false");
    array = last_post_id.find("#demo").attr("src").split("/");
    var locale = array[array.length-1].split(".")[0];
    var photo_id = last_post_id.attr("id");
    var caption = last_post_id.find("#photo_name").text();
    HeritageGoService.prototype.suggestPhotoCaption(photo_id, caption, locale);
    last_post_id.find("#photo_name").attr("contenteditable", "true");}
  catch(err) {
    return false;
  }
};


function stop_shaking(image){
  $(image).removeAttr("class");
  $(image).parents(".popup_container").find(".popup_content").css("display", "flex");
  $(image).parents(".popup_container").find(".popup_content").css("flex-direction", "column");
  stopped = $(image).parents(".popup_container").find(".popup_content")
};

$('html').click(function(e) {
  if (stopped != false && e.target.id != "popup_content" && $(e.target).parents("#popup_content").length == 0 && e.target.id != "demo" && $(e.target).parents("#demo").length == 0) {
    stopped.css("display", "none");
  };
});
