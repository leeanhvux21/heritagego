var last_new_feed="-1";
var last_flag;
var offset_number = 3;
var elementIsClicked = false;
var default_locale = find_default_locale();
var already_suggested= false;
var stopped = false;


/**
 * Return the current browser's language with the format of 3-alpha-code
 * @return: a string: define the browser's language with the format of 3-alpha-code
 */
function find_default_locale(){
  language_convert = {
    "aa":"aar", "ab":"abk", "af":"afr", "ak":"aka", "am":"amh", "ar":"ara", "an":"arg", "as":"asm", "av":"ava", "ae":"ave",
    "ay":"aym", "az":"aze", "ba":"bak", "bm":"bam", "be":"bel", "bn":"ben", "bh":"bih", "bi":"bis", "bo":"bod", "bs":"bos",
    "br":"bre", "bg":"bul", "ca":"cat", "cs":"ces", "ch":"cha", "ce":"che", "cu":"chu", "cv":"chv", "kw":"cor", "co":"cos",
    "cr":"cre", "cy":"cym", "da":"dan", "de":"deu", "dv":"div", "dz":"dzo", "el":"ell", "en":"eng", "eo":"epo", "et":"est",
    "eu":"eus", "ee":"ewe", "fo":"fao", "fa":"fas", "fj":"fij", "fl":"fil", "fi":"fin", "fr":"fra", "fy":"fry", "ff":"ful",
    "gd":"gla", "ga":"gle", "gl":"glg", "gv":"glv", "gn":"grn", "gu":"guj", "ht":"hat", "ha":"hau", "sh":"hbs", "he":"heb",
    "hz":"her", "hi":"hin", "ho":"hmo", "hr":"hrv", "hu":"hun", "hy":"hye", "ig":"ibo", "io":"ido", "ii":"iii", "iu":"iku",
    "ie":"ile", "ia":"ina", "id":"ind", "ik":"ipk", "is":"isl", "it":"ita", "jv":"jav", "ja":"jpn", "kl":"kal", "kn":"kan",
    "ks":"kas", "ka":"kat", "kr":"kau", "kk":"kaz", "km":"khm", "ki":"kik", "rw":"kin", "ky":"kir", "kv":"kom", "kg":"kon",
    "ko":"kor", "kj":"kua", "ku":"kur", "lo":"lao", "la":"lat", "lv":"lav", "li":"lim", "ln":"lin", "lt":"lit", "lb":"ltz",
    "lu":"lub", "lg":"lug", "mh":"mah", "ml":"mal", "mr":"mar", "mk":"mkd", "mg":"mlg", "mt":"mlt", "mn":"mon", "mi":"mri",
    "ms":"msa", "my":"mya", "na":"nau", "nv":"nav", "nr":"nbl", "nd":"nde", "ng":"ndo", "ne":"nep", "nl":"nld", "nn":"nno",
    "nb":"nob", "no":"nor", "ny":"nya", "oc":"oci", "oj":"oji", "or":"ori", "om":"orm", "os":"oss", "pa":"pan", "pi":"pli",
    "pl":"pol", "pt":"por", "ps":"pus", "qu":"que", "rm":"roh", "ro":"ron", "rn":"run", "ru":"rus", "sg":"sag", "sa":"san",
    "si":"sin", "sk":"slk", "sl":"slv", "se":"sme", "sm":"smo", "sn":"sna", "sd":"snd", "so":"som", "st":"sot", "es":"spa",
    "sq":"sqi", "sc":"srd", "sr":"srp", "ss":"ssw", "su":"sun", "sw":"swa", "sv":"swe", "ty":"tah", "ta":"tam", "tt":"tat",
    "te":"tel", "tg":"tgk", "tl":"tgl", "th":"tha", "ti":"tir", "to":"ton", "tn":"tsn", "ts":"tso", "tk":"tuk", "tr":"tur",
    "tw":"twi", "ug":"uig", "uk":"ukr", "ur":"urd", "uz":"uzb", "ve":"ven", "vi":"vie", "vo":"vol", "wa":"wln", "wo":"wol",
    "xh":"xho", "yi":"yid", "yo":"yor", "za":"zha", "zh":"zho", "zu":"zul"
  };
  return language_convert[navigator.language.substring(0,2)];
};


/**
 * Show caption depend on browser's current language and available languages.
 * Highest priority: Caption in the same language with browser
 * then English if available
 * else return any language available
 * @param: photo: string - photo's id
 * @return: a string: Photo's caption
 */
function find_suitable_language(photo){
  var english_available = false;
  var available_languages = photo["title"];
  for (index = 0; index < photo["title"].length; index++){
    let element = photo["title"][index];
    if (element["locale"] == default_locale) {
      return element["content"];
    }else if (element["locale"] == "en") {
      english_available = true;
      var english_caption = element["content"];
    };
};
  if (english_available == true){
    return english_caption;
  };
  return photo["title"][0]["content"];
};


/**
 * Hide already exist languages caption in pop-up menu
 * @param: photo: photo
 * @param: clone: selector of the clone div
 */
function hide_exist_language(photo, clone){
  for (index = 0; index < photo["title"].length; index++){
    clone.find("." + photo["title"][index]["locale"]).attr("style", "display:none !important");
  }
};


/**
 * Run provided function getPhoto
 * Then display gotten photo
 * @param: photos: Array of photos' id
 */
function get_photo(photos){
  for (index = 0; index < photos.length; index++){
  mHeritageGoService.getPhoto(photos[index]).then( function (photo) {display(photo);})
}
};


/**
 * Clone written HTML photo-post-template
 * Then fill all fields with corresponding informations
 * @param: photo: string - photo's id
 */
function display(photo){
  // Clone to a new photo-post-template
  var clone = $('.post_1:last').clone(false).appendTo("section").hide().fadeIn(1600) ;
  clone.removeClass("post_1")
  // Change post's photo
  clone.find('#photo').attr('src',"http:" + photo['image_url']);
  clone.find('#area_name').text(photo["area_name"]);
  // Change post's caption
  hide_exist_language(photo, clone);
  var suitable_language = find_suitable_language(photo);
  clone.find('#photo_name').text(suitable_language);
  clone.find('#user_avatar').attr('src',"http:" + photo["account"]["picture_url"]);
  clone.find('#creation_time').text(photo["capture_time"]);
  clone.find("#demo").attr('src', "./img/trans_icon.png");
  clone.find("#demo").attr("alt", suitable_language);
  var photo_id = photo["photo_id"]
  // Change post's id to photo's id
  clone.attr('id', ""+photo_id);

};


/**
 * Call provided function getPhotos
 * Get an array of photos then get their detailed information
 * @param: offset_number: INTEGER - number of photos that will be ignored
 */
function get_photos(offset_number){
  mHeritageGoService.getPhotos({offset:offset_number, limit:1})
  .then(photos => {get_photo(photos, offset_number); })
};


/**
 * When scrolling, finds non-shaking icon an make it shake
 */
$(window).scroll(function() {
  // When scrolling to the end of the page, load new photos
  if($(window).scrollTop()+2 >= $(document).height() - $(window).height()) {
    get_photos(offset_number, 1);
    offset_number++;
  }
  // Hide pop-up menu
  $(last_flag).parents(".popup_content").css("display", "none");
  // Find none-shaking icon and make it shake
  shake_icon()
  // Create blured clone if needed
  if (document.getElementById("clone-feed").innerHTML != document.getElementById("new_feed").innerHTML){
    document.getElementById("clone-feed").innerHTML = document.getElementById("new_feed").innerHTML;
  }
  document.getElementById("clone-feed-container").scrollTop = window.scrollY;

  $(last_flag).parents(".popup_container").find("#demo").attr("src", "./img/trans_icon.png");
  $(last_flag).parents(".caption").find("#photo_name").attr("contenteditable", "false");

});


/**
 * When the page is ready, get and display three photos on screen
 */
$(document).ready(get_three_photos());


/**
 * Get and display three photos on screen
 */
function get_three_photos(){
  for (i = 0; i < 3; i++) {
    get_photos(i);
  }
};

/**
 * When user choose language, replace translate icon by language icon
 * and make caption be contenteditable.
 */
function change_lang(flag){
  // if cuurent flag is different from last flag, replace language icon by translate icon
  if (flag != last_flag){
    $(last_flag).parents(".popup_container").find("#demo").attr("src", "./img/trans_icon.png");
    $(last_flag).parents(".caption").find("#photo_name").attr("contenteditable", "false");

  }

  // replace translate icon by new language icon 
  $(flag).parents(".popup_container").find("#demo").attr("src", flag.src);
  $(flag).parents(".caption").find("#photo_name").attr("contenteditable", "true");
  last_flag = flag;
  // update innerHTML for blur section
  document.getElementById("clone-feed").innerHTML = document.getElementById("new_feed").innerHTML;
}

/**
 * When user click out the current post, change language icon back to translate icon
 * and update innerHTML for blur section
 */
function change_icon(target) {
  if ($(last_flag).parents(".container")[0] != target){
    $(last_flag).parents(".popup_container").find("#demo").attr("src", "./img/trans_icon.png");
    $(last_flag).parents(".caption").find("#photo_name").attr("contenteditable", "false");
    // update innerHTML for blur section
    document.getElementById("clone-feed").innerHTML = document.getElementById("new_feed").innerHTML;
    $(last_flag).parents(".popup_container").find("#demo").attr("class", "shaking_image")
  }
}


/**
 * Find non-shaking default language icon, make it shake
 * And hide pop-up language list
 */
function shake_icon(){
  not_shaking_icon = $(".select_language_button").find("#demo").not(".shaking_image");
  if (not_shaking_icon.attr("src") == "./img/trans_icon.png"){
    not_shaking_icon.attr("class", "shaking_image");
    not_shaking_icon.parents(".popup_container").find(".popup_content").css("display", "none")
}
}


/**
 * When hitting Enter
 * Suggest the caption to the server
 * @param: event: keypress event
 */
$(document).keypress(function(event){
  var keycode = (event.keyCode ? event.keyCode : event.which);
	if(keycode === 13){
    var photo_name = $(last_flag).parents(".caption").find("#photo_name");
    photo_name.removeAttr("onfocusout");
    suggest_caption();
    photo_name.attr("onfocusout", "suggest_caption()");
	}
});


/**
 * Suggest the last edited caption to the server
 */
function suggest_caption(){
  try {
    var photo_name = $(last_flag).parents(".caption").find("#photo_name");
    photo_name.attr("contenteditable", "false");
    array = $(last_flag).parents(".popup_container").find("#demo").attr("src").split("/");
    var locale = array[array.length-1].split(".")[0];
    var photo_id = $(last_flag).parents(".post_1").attr("id");
    var caption = photo_name.text();
    HeritageGoService.prototype.suggestPhotoCaption(photo_id, caption, locale);
    photo_name.attr("contenteditable", "true");
  }
  catch(err) {
    return false;
  }
};


/**
 * Stop the shaking animation and show pop-up menu
 * @param: image: the target tag <img>
 */
function stop_shaking(image){
  shake_icon()
  $(image).removeAttr("class");
  $(image).parents(".popup_container").find(".popup_content").css("display", "flex");
  $(image).parents(".popup_container").find(".popup_content").css("flex-direction", "column");
  stopped = $(image).parents(".popup_container").find(".popup_content")
};


/**
 * When clicking outside the pop-up menu, hide the pop-up menu and shake icon
 * @param: event: click event
 */
$('html').click(function(event) {
  if (stopped != false && event.target.id != "popup_content" && event.target.id != "demo") {
    stopped.css("display", "none");
    shake_icon()
  };
});


/**
 * When clicking on the locked icon, open the lock, show password
 * When clicking on the unlocked icon, close the lock, hide password
 */
function hide_and_show_password() {
  var lock= document.getElementById("lock_icon");
  var button = document.getElementById("password");
  if (button.type === "password") {
    button.type = "text";
    lock.className = "fas fa-lock-open";
  } else {
    button.type = "password";
     lock.className = "fas fa-lock";
  }
}
