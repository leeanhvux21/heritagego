HOW TO INSTALL:
  Linux/ Windows:

    Unzip group_3.zip to folder group_3
    In the folder group_3, right click on index.html then select your favorite browser.
    RECOMMENDATION: GOOGLE CHROME (lastest version)
