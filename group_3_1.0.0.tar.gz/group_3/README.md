Héritage GO

****************************

Project's name : Heritage Go

Description : Héritage GO is a social networking service dedicated to cultural and historical heritages, developed by the non-profit organization Heritage Observatory.

            HTML: - Know how to use semantic markup
            
            HTML: - Know how to structure the DOM properly
            
            CSS: - Know when to use ids and classes
            
            CSS: - Understand the grid system
            
            CSS: - Implement responsive layouts with media queries
            
            JS: - Manipulate the DOM
            
Support : team 3 (VDINH, LAVU, NSON), contact us on Bitrix.

Roadmap : the final release will comes after the time when WP20 is finished.

Contributing : we're open to contributions and every idea will be reviewed before we can put them into our project.

Project status : learning out come


