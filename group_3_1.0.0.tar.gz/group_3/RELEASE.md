VERSION 0.3.0 - 25/06/2019: Waypoint 1 to waypoint 19.
	
    	Fix bug and website's response.
    	
    	Login section.
    	
    	Photo post section.
    	
    	Auto load photo when scroll down.
    
    	Blur content.
    
    	Translate.


VERSION 0.1.0 - 15/06/2019:

    	Waypoint 1 to 17 : Automatically generate new photo while scrolling.